<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('purchase_payments', function (Blueprint $table) {
            $table->id();

            $table->foreignId('tenant_id')
                ->constrained('tenants')
                ->cascadeOnDelete();

            $table->foreignId('purchase_id')
                ->constrained('purchases')
                ->cascadeOnDelete();

            $table->foreignId('recorded_by')
                ->constrained('users')
                ->restrictOnDelete();

            $table->decimal('amount', 15, 2);

            $table->string('method');

            $table->string('reference')->nullable();

            $table->text('notes')->nullable();

            $table->timestamp('paid_at');

            $table->timestamps();

            $table->index([
                'tenant_id',
                'purchase_id',
            ]);

            $table->index([
                'tenant_id',
                'paid_at',
            ]);

            $table->index([
                'tenant_id',
                'method',
            ]);

            $table->unique([
                'tenant_id',
                'reference',
            ]);
        });
    }


    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('purchase_payments');
    }
};
