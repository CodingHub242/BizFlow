<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class BizFlowRolePermissionSeeder extends Seeder
{
    public const DEFAULT_ROLES = [
        'Owner',
        'Administrator',
        'Manager',
        'Salesperson',
        'Cashier',
        'Inventory Officer',
        'Accountant',
    ];

    public const PERMISSIONS = [
        // Customers
        'customers.view',
        'customers.create',
        'customers.update',
        'customers.delete',

        // Sales
        'sales.view',
        'sales.create',
        'sales.update',
        'sales.delete',

        // Products / Services
        'products.view',
        'products.create',
        'products.update',
        'products.delete',
        'products.change_cost',

        // Inventory
        'inventory.view',
        'inventory.receive',
        'inventory.adjust',
        'inventory.transfer',
        'inventory.import',

        // Branches
        'branches.view',
        'branches.create',
        'branches.update',
        'branches.delete',

        // Expenses
        'expenses.view',
        'expenses.create',
        'expenses.update',
        'expenses.delete',

        // Invoices
        'invoices.view',
        'invoices.create',
        'invoices.update',
        'invoices.cancel',
        'invoices.record_payment',

        // Reports
        'reports.view',
        'reports.view_profit',

        // Employees
        'employees.view',
        'employees.create',
        'employees.update',
        'employees.manage_roles',

        // Roles
        'roles.view',
        'roles.create',
        'roles.update',
        'roles.delete',

        // Migration Center
        'migration.view',
        'migration.create',
        'migration.import',

        // Categories
        'categories.view',
        'categories.create',
        'categories.update',
        'categories.delete',

        // Business Settings
        'settings.view',
        'settings.update',
        'settings.update_logo',

        // Employee item requests
        'employee_item_requests.view',
        'employee_item_requests.create',
        'employee_item_requests.approve',
        'employee_item_requests.issue',
        'employee_item_requests.return',
        'employee_item_requests.manage',
    ];

    public const ROLE_PERMISSIONS = [
    'Owner' => [
        'customers.view',
        'customers.create',
        'customers.update',
        'customers.delete',

        'sales.view',
        'sales.create',
        'sales.update',
        'sales.delete',

        'products.view',
        'products.create',
        'products.update',
        'products.delete',
        'products.change_cost',

        'inventory.view',
        'inventory.receive',
        'inventory.adjust',
        'inventory.transfer',
        'inventory.import',

        'branches.view',
        'branches.create',
        'branches.update',
        'branches.delete',

        'expenses.view',
        'expenses.create',
        'expenses.update',
        'expenses.delete',

        'invoices.view',
        'invoices.create',
        'invoices.update',
        'invoices.cancel',
        'invoices.record_payment',

        'reports.view',
        'reports.view_profit',

        'employees.view',
        'employees.create',
        'employees.update',
        'employees.manage_roles',

        'roles.view',
        'roles.create',
        'roles.update',
        'roles.delete',

        'migration.view',
        'migration.create',
        'migration.import',

        // Categories
        'categories.view',
        'categories.create',
        'categories.update',
        'categories.delete',

        // Business Settings
        'settings.view',
        'settings.update',
        'settings.update_logo',

        'employee_item_requests.view',
        'employee_item_requests.create',
        'employee_item_requests.approve',
        'employee_item_requests.issue',
        'employee_item_requests.return',
        'employee_item_requests.manage',
    ],

    'Administrator' => [
        'customers.view',
        'customers.create',
        'customers.update',
        'customers.delete',

        'sales.view',
        'sales.create',
        'sales.update',
        'sales.delete',

        'products.view',
        'products.create',
        'products.update',
        'products.delete',
        'products.change_cost',

        'inventory.view',
        'inventory.receive',
        'inventory.adjust',
        'inventory.transfer',
        'inventory.import',

        'branches.view',
        'branches.create',
        'branches.update',
        'branches.delete',

        'expenses.view',
        'expenses.create',
        'expenses.update',
        'expenses.delete',

        'invoices.view',
        'invoices.create',
        'invoices.update',
        'invoices.cancel',
        'invoices.record_payment',

        'reports.view',
        'reports.view_profit',

        'employees.view',
        'employees.create',
        'employees.update',
        'employees.manage_roles',

        'roles.view',
        'roles.create',
        'roles.update',
        'roles.delete',

        'migration.view',
        'migration.create',
        'migration.import',

        // Categories
        'categories.view',
        'categories.create',
        'categories.update',
        'categories.delete',

        // Business Settings
        'settings.view',
        'settings.update',
        'settings.update_logo',

        'employee_item_requests.view',
        'employee_item_requests.create',
        'employee_item_requests.approve',
        'employee_item_requests.issue',
        'employee_item_requests.return',
        'employee_item_requests.manage',
    ],

    'Manager' => [
        'customers.view',
        'customers.create',
        'customers.update',

        'sales.view',
        'sales.create',
        'sales.update',

        'products.view',
        'products.create',
        'products.update',

        'inventory.view',
        'inventory.receive',
        'inventory.adjust',
        'inventory.transfer',
        'inventory.import',

        'branches.view',
        'branches.create',
        'branches.update',

        'expenses.view',
        'expenses.create',
        'expenses.update',

        'invoices.view',
        'invoices.create',
        'invoices.update',
        'invoices.record_payment',

        'reports.view',
        'reports.view_profit',

        'employees.view',
        'employees.create',
        'employees.update',

        // Categories
        'categories.view',
        'categories.create',
        'categories.update',

        // Business Settings
        'settings.view',

        'employee_item_requests.view',
        'employee_item_requests.create',
    ],

    'Salesperson' => [
        'customers.view',
        'customers.create',
        'customers.update',

        'sales.view',
        'sales.create',
        'sales.update',

        'products.view',

        'inventory.view',

        'invoices.view',
        'invoices.create',
        'invoices.record_payment',

        // Categories
        'categories.view',

        'employee_item_requests.view',
    ],

    'Cashier' => [
        'customers.view',
        'customers.create',
        'customers.update',

        'sales.view',
        'sales.create',

        'products.view',

        'inventory.view',

        'invoices.view',
        'invoices.create',
        'invoices.record_payment',

        // Categories
        'categories.view',
    ],

    'Inventory Officer' => [
        'customers.view',

        'products.view',
        'products.create',
        'products.update',

        'inventory.view',
        'inventory.receive',
        'inventory.adjust',
        'inventory.transfer',
        'inventory.import',

        'branches.view',

        'sales.view',

        'invoices.view',

        // Categories
        'categories.view',

        'employee_item_requests.view',
        'employee_item_requests.issue',
        'employee_item_requests.return',
        'employee_item_requests.manage',
    ],

    'Accountant' => [
        'customers.view',

        'sales.view',

        'products.view',

        'inventory.view',

        'expenses.view',
        'expenses.create',
        'expenses.update',
        'expenses.delete',

        'invoices.view',
        'invoices.create',
        'invoices.update',
        'invoices.record_payment',

        'reports.view',
        'reports.view_profit',

        'migration.view',
        'migration.create',
        'migration.import',

        // Categories
        'categories.view',
    ],
];

    public function run(): void
    {
        foreach (self::PERMISSIONS as $permission) {
            Permission::findOrCreate($permission, 'web');
        }
    }


    public function provisionTenantRoles(int $tenantId): void
    {
        foreach (self::PERMISSIONS as $permission) {
            Permission::findOrCreate($permission, 'web');
        }

        setPermissionsTeamId($tenantId);

        foreach (self::DEFAULT_ROLES as $roleName) {
            $role = Role::query()->firstOrCreate([
                'tenant_id' => $tenantId,
                'name' => $roleName,
                'guard_name' => 'web',
            ]);

            // Initialize permissions for each newly created role.
            if ($role->wasRecentlyCreated) {
                $role->syncPermissions(
                    self::ROLE_PERMISSIONS[$roleName] ?? []
                );
            }
        }
    }


    // public function provisionTenantRoles(int $tenantId): void
    // {
    //     foreach (self::PERMISSIONS as $permission) {
    //         Permission::findOrCreate($permission, 'web');
    //     }

    //     setPermissionsTeamId($tenantId);

    //     // foreach (self::DEFAULT_ROLES as $roleName) {
    //     //     $role = Role::findOrCreate($roleName, 'web');

    //     //     $role->syncPermissions(
    //     //         self::ROLE_PERMISSIONS[$roleName] ?? []
    //     //     );
    //     // }
    //     foreach (self::DEFAULT_ROLES as $roleName) {
    //         $role = Role::query()->firstOrCreate(
    //             [
    //                 'tenant_id' => $tenantId,
    //                 'name' => $roleName,
    //                 'guard_name' => 'web',
    //             ]
    //         );
    //     }

    //     // Only initialize permissions when this role was just created.
    //     if ($role->wasRecentlyCreated) {
    //         $role->syncPermissions(
    //             self::ROLE_PERMISSIONS[$roleName] ?? []
    //         );
    //     }
    // }
}