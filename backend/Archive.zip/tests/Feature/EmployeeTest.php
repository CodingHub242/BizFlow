<?php

namespace Tests\Feature;

use App\EmploymentStatus;
use App\Models\Branch;
use App\Models\Employee;
use App\Models\Tenant;
use Spatie\Permission\Models\Role;
use App\Models\User;
use Database\Seeders\BizFlowRolePermissionSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Database\QueryException;
use App\Services\Tenant\TenantProvisioningService;
use Tests\TestCase;

class EmployeeTest extends TestCase
{
    use RefreshDatabase;

   protected function setUp(): void
    {
        parent::setUp();

        $this->seed(BizFlowRolePermissionSeeder::class);

//         $provisioning = app(TenantProvisioningService::class);
// $provisioning->provision($tenant);

// setPermissionsTeamId($tenant->id);

// $role = Role::query()
//     ->where('tenant_id', $tenant->id)
//     ->where('name', 'Administrator')
//     ->where('guard_name', 'web')
//     ->firstOrFail();
    }

    public function test_employee_domain_enforces_relationships_tenant_isolation_and_uniqueness(): void
    {
        $tenantA = Tenant::factory()->create();
        $tenantB = Tenant::factory()->create();

         $provisioning = app(TenantProvisioningService::class);

        $provisioning->provision($tenantA);
        $provisioning->provision($tenantB);

        $branchA = Branch::factory()->create([
            'tenant_id' => $tenantA->id,
        ]);

        $userA = User::factory()->create([
            'tenant_id' => $tenantA->id,
        ]);

       

        $employee = Employee::create([
            'tenant_id' => $tenantA->id,
            'user_id' => $userA->id,
            'branch_id' => $branchA->id,
            'employee_number' => 'EMP-00001',
            'phone' => '+233201234567',
            'job_title' => 'Salesperson',
            'employment_status' => EmploymentStatus::ACTIVE,
            'hired_at' => '2026-09-25',
        ]);

        // Core employee data.
        $this->assertSame($tenantA->id, $employee->tenant_id);
        $this->assertSame($userA->id, $employee->user_id);
        $this->assertSame($branchA->id, $employee->branch_id);
        $this->assertSame('EMP-00001', $employee->employee_number);
        $this->assertSame('Salesperson', $employee->job_title);

        // Enum/date casts.
        $this->assertSame(
            EmploymentStatus::ACTIVE,
            $employee->employment_status
        );

        $this->assertSame(
            '2026-09-25',
            $employee->hired_at->toDateString()
        );

        // Relationships.
        $this->assertTrue($employee->tenant->is($tenantA));
        $this->assertTrue($employee->user->is($userA));
        $this->assertTrue($employee->branch->is($branchA));

        $this->assertTrue(
            $tenantA->employees->contains($employee)
        );

        $this->assertTrue(
            $branchA->employees->contains($employee)
        );

        $this->assertTrue(
            $userA->employee->is($employee)
        );

        // Another tenant may use the same employee number.
        $userB = User::factory()->create([
            'tenant_id' => $tenantB->id,
        ]);

        $employeeB = Employee::create([
            'tenant_id' => $tenantB->id,
            'user_id' => $userB->id,
            'employee_number' => 'EMP-00001',
            'employment_status' => EmploymentStatus::ACTIVE,
        ]);

         setPermissionsTeamId($tenantA->id);

        $this->assertSame('EMP-00001', $employeeB->employee_number);
        $this->assertSame($tenantB->id, $employeeB->tenant_id);

        // Same tenant cannot reuse an employee number.
        $duplicateNumberUser = User::factory()->create([
            'tenant_id' => $tenantA->id,
        ]);

        try {
            Employee::create([
                'tenant_id' => $tenantA->id,
                'user_id' => $duplicateNumberUser->id,
                'employee_number' => 'EMP-00001',
                'employment_status' => EmploymentStatus::ACTIVE,
            ]);

            $this->fail(
                'Duplicate employee number was allowed within the same tenant.'
            );
        } catch (QueryException) {
            $this->assertTrue(true);
        }

        // Same user cannot have two employee records in the same tenant.
        try {
            Employee::create([
                'tenant_id' => $tenantA->id,
                'user_id' => $userA->id,
                'employee_number' => 'EMP-00002',
                'employment_status' => EmploymentStatus::ACTIVE,
            ]);

            $this->fail(
                'The same user was allowed multiple employee records within the tenant.'
            );
        } catch (QueryException) {
            $this->assertTrue(true);
        }
    }

  public function test_employee_api_rejects_cross_tenant_user_and_branch(): void
{
    $tenantA = Tenant::factory()->create();
    $tenantB = Tenant::factory()->create();

    $provisioning = app(TenantProvisioningService::class);

    $provisioning->provision($tenantA);
    $provisioning->provision($tenantB);

    $userA = User::factory()->create([
        'tenant_id' => $tenantA->id,
    ]);

    $userB = User::factory()->create([
        'tenant_id' => $tenantB->id,
    ]);

    $branchB = Branch::factory()->create([
        'tenant_id' => $tenantB->id,
    ]);

    setPermissionsTeamId($tenantA->id);

    $role = Role::query()
        ->where('tenant_id', $tenantA->id)
        ->where('name', 'Administrator')
        ->where('guard_name', 'web')
        ->firstOrFail();

    $userA->assignRole($role);

    $userA->givePermissionTo('employees.create');

    $response = $this
        ->actingAs($userA, 'sanctum')
        ->postJson('/api/employees', [
            'user_id' => $userB->id,
            'branch_id' => $branchB->id,
            'employee_number' => 'EMP-CROSS-TENANT-001',
            'phone' => '+233201234567',
            'job_title' => 'Salesperson',
            'employment_status' => EmploymentStatus::ACTIVE->value,
            'hired_at' => '2026-09-25',
        ]);

    $response
        ->assertStatus(422)
        ->assertJsonValidationErrors([
            'user_id',
            'branch_id',
        ]);

    $this->assertDatabaseMissing('employees', [
        'tenant_id' => $tenantA->id,
        'employee_number' => 'EMP-CROSS-TENANT-001',
    ]);
}
}